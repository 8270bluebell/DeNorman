import java.util.concurrent.CountDownLatch;

public class UpAndDown implements Runnable {
    private final CountDownLatch startLatch;
    private final CountDownLatch endLatch;
    private final int number;

    public UpAndDown(int number, CountDownLatch startLatch, CountDownLatch endLatch) {
        this.number = number;
        this.startLatch = startLatch;
        this.endLatch = endLatch;
    }

    @Override
    public void run() {
        if (Thread.currentThread().getName().equals("Thread-1")) {
            countUp();
            startLatch.countDown();
        } else if (Thread.currentThread().getName().equals("Thread-2")) {
            try {
                startLatch.await();
                countDown();
                endLatch.countDown();
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
            }
        }
    }

    private void countUp() {
        for (int i = number; i <= 20; i++) {
            System.out.print(i + " ");
        }
        System.out.println();
    }

    private void countDown() {
        for (int i = 20; i >= 0; i--) {
            System.out.print(i + " ");
        }
        System.out.println();
    }

    public static void main(String[] args) {
        try {
            CountDownLatch startLatch = new CountDownLatch(1);
            CountDownLatch endLatch = new CountDownLatch(1);
            UpAndDown countInstance = new UpAndDown(0, startLatch, endLatch);
            Thread thread1 = new Thread(countInstance, "Thread-1");
            Thread thread2 = new Thread(countInstance, "Thread-2");

            thread1.start();
            thread2.start();

            endLatch.await();
        } catch (IllegalArgumentException e) {
            System.out.println("Error: " + e.getMessage());
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        }
    }
}
